<script setup>
import { h, ref, onMounted, createTextVNode } from 'vue';
import List from "./List.vue";
import TableHeader from "./TableHeader.vue";
import TableData from "./TableData.vue";
import { loadData } from "./dbUtils";

const data = ref([])
const dbUrl = ref("http://localhost:3000/recipes.json")
const dbParser = ref(db => db.slice(0, 50))
const tableBuildingData = ref({
    "Name": recipe => createTextVNode(recipe.name),
    "Description": recipe => createTextVNode(recipe.description),
    "Image": recipe => h('img', { src: recipe.image, alt: recipe.alt }),
    "Nutrients": recipe => h(List, { list: Object.entries(recipe.nutrients).map(k => k[0] + ": " + k[1]) }),
    "Author": recipe => createTextVNode(recipe.author),
    "Website": recipe => h('a', { href: recipe.url, style: { 'white-space': 'nowrap' } }, "Visit Website"),
})

onMounted(() => loadData(dbUrl.value).then(response => data.value = dbParser.value(response)))  
</script>

<template>
    <h1>Accessible Composition API Table</h1>
    <div class="table responsive">
        <table class="table" v-if="tableBuildingData != null">
            <caption>Recipes</caption>
            <thead class="table-dark">
                <TableHeader v-bind:headers="Object.keys(tableBuildingData)" scopeInfo="col"></TableHeader>
            </thead>
            <tbody>
                <TableData v-bind:data="data" v-bind:renderers="Object.values(tableBuildingData)"></TableData>
            </tbody>
        </table>
    </div>
</template>

<style scoped>
:deep(th),
:deep(td) {
    border: 2px solid #000000;
    vertical-align: middle;
}

:deep(img) {
    width: width;
    height: 200px;
    object-fit: cover;
    border-radius: 24px;
}
</style>
